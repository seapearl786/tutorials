# Databricks notebook source
# MAGIC %run ./_utility-methods $lesson="2.4L"

# COMMAND ----------

DA.cleanup()
DA.init()
DA.conclude_setup()

